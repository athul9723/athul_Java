package com.springbootDBexample.exception;

public class InvalidTicketIDException extends RuntimeException {
	public InvalidTicketIDException(String message) {
		super(message);
	}

}