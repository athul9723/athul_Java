package com.app;

import java.sql.SQLException;
import java.util.Scanner;
import com.data.Inventory;
import com.service.ShoppingCart;

class EcommDataMain {	
	
		public static void main(String[] args) throws SQLException {
			
				Inventory inventory=new Inventory();
				ShoppingCart scart=new ShoppingCart();
				Scanner sc=new Scanner(System.in);
				
				while(true) {
					System.out.println("1. Search for Products");
					System.out.println("2. Add to Shopping Cart");
					System.out.println("3. View Shopping Cart");
					System.out.println("4. Checkout Shopping Cart");
					System.out.println("5. Exit");
				
					System.out.println("Choose an option");
					int option=sc.nextInt();
			
					switch(option) {
						case 1: System.out.println("Enter product name");
								String pname=sc.next();
								inventory.searchProducts(pname);	                   
								System.out.println();
								break;
					
						case 2: System.out.println("Enter Product ID");
								int pid=sc.nextInt();
								System.out.println("Enter Product Quantity");
								int pquantity=sc.nextInt();
								scart.addProduct(pid, pquantity);
								System.out.println("Product added successfully to cart\n");
								break;
					
						case 3: scart.viewCart();
								System.out.println();
								break;
					
						case 4: scart.checkout();
								System.out.println();
								break;
					
						case 5: System.exit(0);
								System.out.println();
								break;
					
						default: System.out.println("Invalid option\n");
								 break;
					}
			
			}
		
		}

}
