package com.app;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnectionImpl implements DatabaseConnection{

	private static final String url="jdbc:mysql://localhost:3306/EEcommerceDB";
	private static final String username="root";
	private static final String password="pass@word1";

	
	@Override
	public Connection getConnection() throws SQLException {
		return DriverManager.getConnection(url,username,password);
	
	}

	@Override
	public void closeConnection(Connection connection) throws SQLException {
		connection.close();
		
	}

}


