package com.app;

import java.util.List;
import java.util.Scanner;
import com.data.Inventory;
import com.service.ShoppingCart;

class EcommDataMain {	
	
		public static void main(String[] args) {
			
				Inventory inventory=new Inventory();
				ShoppingCart scart=new ShoppingCart(inventory);
				Scanner sc=new Scanner(System.in);
				
				while(true) {
					System.out.println("1. Search for Products");
					System.out.println("2. Add to Shopping Cart");
					System.out.println("3. View Shopping Cart");
					System.out.println("4. Checkout Shopping Cart");
					System.out.println("5. Exit");
				
					System.out.println("Choose an option");
					int option=sc.nextInt();
			
					switch(option) {
						case 1: System.out.println("Enter product name");
								String pname=sc.next();
								List<Product> products = inventory.searchProducts(pname);
			                    if (products.isEmpty()) {
			                        System.out.println("No products found");
			                    } 
			                    else {
			                    	for(Product p:inventory.getProductList()) {
			                    		if(p.product_name.equals(pname)) {
			                    			System.out.println("Product ID: "+p.getProduct_id());
			                    			System.out.println("Product Name: "+p.getProduct_name());
			                    			System.out.println("Product Category: "+p.getProduct_category());
			                    			System.out.println("Product Specifications: "+p.getProduct_specifications());
			                    			System.out.println("Product Price: "+p.getPrice());
			                    		}
						
			                    	}
			                    }
								System.out.println();
								break;
					
						case 2: System.out.println("Enter Product ID");
								int pid=sc.nextInt();
								System.out.println("Enter Product Quantity");
								int pquantity=sc.nextInt();
								scart.addProduct(pid, pquantity);
								System.out.println("Product added successfully to cart\n");
								break;
					
						case 3: scart.viewCart();
								System.out.println();
								break;
					
						case 4: scart.checkout(inventory);
								System.out.println();
								break;
					
						case 5: System.exit(0);
								System.out.println();
								break;
					
						default: System.out.println("Invalid option\n");
								 break;
					}
			
			}
		
		}

}
