package com.data;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.app.Product;

public class Inventory {
	
	public List<Product> productList;
	
	public Inventory(){
		productList=new ArrayList<>();
		productList.add(new Product(1, "Laptop","Electronics","iOS 17 Operating system",10000));
		productList.add(new Product(2, "Headphones","Electronics","Intel core i7",20000));
		productList.add(new Product(3, "Televisions","Electronics","Android TV OS",30000));
		
	}

	public List<Product> getProductList() {
		return productList;
	}

	public void setProductList(List<Product> productList) {
		this.productList = productList;
	}
	
	//Getting Product using ID
	public Product getProduct(int product_id) {
		for(Product p:productList) {
			if(p.getProduct_id()==product_id) {
				return p;
			}
		}
		return null;
	}
	
	//Searching Product using Product Name
	public List<Product> searchProducts(String productName) {
        return productList.stream()
                .filter(product -> product.getProduct_name().toLowerCase().contains(productName.toLowerCase()))
                .collect(Collectors.toList());
	}		
}
	

