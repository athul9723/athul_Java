package com.service;

import java.util.HashMap;
import java.util.Map;

import com.app.Product;
import com.data.Inventory;

public class ShoppingCart {
		
	Map<Integer,Integer> cart;
	Inventory i;
	
	public ShoppingCart(Inventory i) {
		this.cart=new HashMap<>();
		this.i=i;
		
	}
	
	//adding Product
	public void addProduct(Integer product_id,int quantity) {
		cart.put(product_id, cart.getOrDefault(product_id, 0) + quantity);
	}
	
	//Viewing Shopping Cart
	public void viewCart() {
		if (cart.isEmpty()) {
            System.out.println("The shopping cart is empty.");
            return;
        }
		else {
			for(Map.Entry<Integer, Integer> entry : cart.entrySet()) {
				int pid=entry.getKey();
				int q=entry.getValue();
				Product pt=i.getProduct(pid);			
				System.out.println("Product ID: " +pid);
				System.out.println("Product Name: "+pt.getProduct_name());
    			System.out.println("Product Category: "+pt.getProduct_category());
    			System.out.println("Product Specifications: "+pt.getProduct_specifications());
    			System.out.println("Product Price: "+pt.getPrice());
    			System.out.println("Product Quantity: " +q);
				
			}
        }
		
		
	}
	
	
	//Checkout
	public void checkout(Inventory inv) {
		double total= 0;
		if (cart.isEmpty()) {
            System.out.println("No products to checkout!");
            return;
        }
		else {
		for(Map.Entry<Integer, Integer> entry : cart.entrySet()) {
			total+=inv.getProduct(entry.getKey()).getPrice()*entry.getValue();
			System.out.println("Total: "+total);
		}
		cart.clear();
		}
	}	
	
}	